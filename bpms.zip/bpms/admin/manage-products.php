<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bpmsaid']==0)) {
  header('location:logout.php');
}

if(isset($_GET['del'])){
  $productid=intval($_GET['del']);
  $query=mysqli_query($con,"delete from tblproducts where ID='$productid'");
  echo "<script>alert('Product deleted.');</script>";
  echo "<script>window.location.href='manage-products.php'</script>";
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>BPMS | Manage Products</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
</head>
<body class="cbp-spmenu-push">
  <div class="main-content">
    <?php include_once('includes/sidebar.php');?>
    <?php include_once('includes/header.php');?>
    <div id="page-wrapper">
      <div class="main-page">
        <div class="tables">
          <h3 class="title1">Manage Products</h3>
          <div class="table-responsive bs-example widget-shadow">
            <h4>Update Products:</h4>
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Product Name</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Stock Quantity</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $ret=mysqli_query($con,"select * from tblproducts");
                $cnt=1;
                while ($row=mysqli_fetch_array($ret)) {
                ?>
                <tr>
                  <th scope="row"><?php echo $cnt;?></th>
                  <td><?php  echo $row['ProductName'];?></td>
                  <td><?php  echo $row['Category'];?></td>
                  <td><?php  echo $row['Price'];?></td>
                  <td><?php  echo $row['StockQuantity'];?></td>
                  <td>
                    <a href="edit-product.php?editid=<?php echo $row['ID'];?>" class="btn btn-primary">Edit</a>
                    <a href="manage-products.php?del=<?php echo $row['ID'];?>" class="btn btn-danger" onclick="return confirm('Do you really want to delete this product?');">Delete</a>
                  </td>
                </tr>
                <?php 
                $cnt=$cnt+1;
                }?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <?php include_once('includes/footer.php');?>
  </div>
</body>
</html>