<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bpmsaid']==0)) {
  header('location:logout.php');
}

if(isset($_POST['submit'])){
  $eid=$_GET['editid'];
  $suppliername=$_POST['suppliername'];
  $purchasedate=$_POST['purchasedate'];
  $totalamount=0;
  
  $query=mysqli_query($con, "update tblpurchases set SupplierName='$suppliername',PurchaseDate='$purchasedate' where ID='$eid'");
  if ($query) {
    // Delete existing items
    mysqli_query($con, "delete from tblpurchase_items where PurchaseID='$eid'");
    
    $productcount = count($_POST['product']);
    for($i=0; $i<$productcount; $i++) {
      $productid = $_POST['product'][$i];
      $quantity = $_POST['quantity'][$i];
      $unitprice = $_POST['unitprice'][$i];
      $totalprice = $quantity * $unitprice;
      $totalamount += $totalprice;
      
      mysqli_query($con, "insert into tblpurchase_items(PurchaseID,ProductID,Quantity,UnitPrice,TotalPrice) value('$eid','$productid','$quantity','$unitprice','$totalprice')");
    }
    
    mysqli_query($con, "update tblpurchases set TotalAmount='$totalamount' where ID='$eid'");
    echo "<script>alert('Purchase order has been updated.');</script>";
  } else {
    echo "<script>alert('Something Went Wrong. Please try again');</script>";
  }
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>BPMS | Edit Purchase</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<script>
function addProductRow() {
  var products = document.getElementById('products');
  var row = document.createElement('div');
  row.className = 'row product-row';
  row.innerHTML = `
    <div class="col-md-4">
      <div class="form-group">
        <label>Product</label>
        <select name="product[]" class="form-control" required>
          <option value="">Select Product</option>
          <?php
          $ret=mysqli_query($con,"select * from tblproducts");
          while ($row=mysqli_fetch_array($ret)) {
          ?>
          <option value="<?php echo $row['ID'];?>"><?php echo $row['ProductName'];?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="col-md-3">
      <div class="form-group">
        <label>Quantity</label>
        <input type="number" class="form-control" name="quantity[]" required>
      </div>
    </div>
    <div class="col-md-3">
      <div class="form-group">
        <label>Unit Price</label>
        <input type="number" class="form-control" name="unitprice[]" step="0.01" required>
      </div>
    </div>
    <div class="col-md-2">
      <div class="form-group">
        <label>&nbsp;</label>
        <button type="button" class="btn btn-danger form-control" onclick="this.parentElement.parentElement.parentElement.remove()">Remove</button>
      </div>
    </div>
  `;
  products.appendChild(row);
}
</script>
</head>
<body class="cbp-spmenu-push">
  <div class="main-content">
    <?php include_once('includes/sidebar.php');?>
    <?php include_once('includes/header.php');?>
    <div id="page-wrapper">
      <div class="main-page">
        <div class="forms">
          <h3 class="title1">Edit Purchase</h3>
          <div class="form-grids row widget-shadow" data-example-id="basic-forms">
            <div class="form-title">
              <h4>Update Purchase Order Information:</h4>
            </div>
            <div class="form-body">
              <form method="post">
                <?php
                $eid=$_GET['editid'];
                $ret=mysqli_query($con,"select * from tblpurchases where ID='$eid'");
                $row=mysqli_fetch_array($ret);
                ?>
                <div class="form-group">
                  <label>Supplier Name</label>
                  <input type="text" class="form-control" name="suppliername" value="<?php echo $row['SupplierName'];?>" required>
                </div>
                <div class="form-group">
                  <label>Purchase Date</label>
                  <input type="date" class="form-control" name="purchasedate" value="<?php echo $row['PurchaseDate'];?>" required>
                </div>
                <div id="products">
                  <?php
                  $ret=mysqli_query($con,"select pi.*,p.ProductName from tblpurchase_items pi 
                    inner join tblproducts p on p.ID=pi.ProductID 
                    where pi.PurchaseID='$eid'");
                  while ($row=mysqli_fetch_array($ret)) {
                  ?>
                  <div class="row product-row">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Product</label>
                        <select name="product[]" class="form-control" required>
                          <option value="">Select Product</option>
                          <?php
                          $pret=mysqli_query($con,"select * from tblproducts");
                          while ($prow=mysqli_fetch_array($pret)) {
                          ?>
                          <option value="<?php echo $prow['ID'];?>" <?php if($prow['ID']==$row['ProductID']) echo 'selected';?>>
                            <?php echo $prow['ProductName'];?>
                          </option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" class="form-control" name="quantity[]" value="<?php echo $row['Quantity'];?>" required>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group">
                        <label>Unit Price</label>
                        <input type="number" class="form-control" name="unitprice[]" value="<?php echo $row['UnitPrice'];?>" step="0.01" required>
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label>&nbsp;</label>
                        <button type="button" class="btn btn-danger form-control" onclick="this.parentElement.parentElement.parentElement.remove()">Remove</button>
                      </div>
                    </div>
                  </div>
                  <?php } ?>
                </div>
                <button type="button" class="btn btn-info" onclick="addProductRow()">Add Product</button>
                <button type="submit" name="submit" class="btn btn-default">Update</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <?php include_once('includes/footer.php');?>
    </div>
  </div>
</body>
</html>