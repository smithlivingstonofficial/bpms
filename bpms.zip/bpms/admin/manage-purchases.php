<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bpmsaid']==0)) {
  header('location:logout.php');
}

if(isset($_GET['del'])){
  $purchaseid=intval($_GET['del']);
  $query=mysqli_query($con,"delete from tblpurchase_items where PurchaseID='$purchaseid'");
  $query=mysqli_query($con,"delete from tblpurchases where ID='$purchaseid'");
  echo "<script>alert('Purchase order deleted.');</script>";
  echo "<script>window.location.href='manage-purchases.php'</script>";
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>BPMS | Manage Purchases</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
</head>
<body class="cbp-spmenu-push">
  <div class="main-content">
    <?php include_once('includes/sidebar.php');?>
    <?php include_once('includes/header.php');?>
    <div id="page-wrapper">
      <div class="main-page">
        <div class="tables">
          <h3 class="title1">Manage Purchases</h3>
          <div class="table-responsive bs-example widget-shadow">
            <h4>Purchase Orders:</h4>
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Purchase Number</th>
                  <th>Supplier</th>
                  <th>Date</th>
                  <th>Total Amount</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $ret=mysqli_query($con,"select * from tblpurchases order by PurchaseDate DESC");
                $cnt=1;
                while ($row=mysqli_fetch_array($ret)) {
                ?>
                <tr>
                  <th scope="row"><?php echo $cnt;?></th>
                  <td><?php echo $row['PurchaseNumber'];?></td>
                  <td><?php echo $row['SupplierName'];?></td>
                  <td><?php echo $row['PurchaseDate'];?></td>
                  <td><?php echo number_format($row['TotalAmount'],2);?></td>
                  <td><?php echo $row['Status'];?></td>
                  <td>
                    <a href="view-purchase.php?viewid=<?php echo $row['ID'];?>" class="btn btn-primary btn-sm">View</a>
                    <a href="edit-purchase.php?editid=<?php echo $row['ID'];?>" class="btn btn-info btn-sm">Edit</a>
                    <a href="manage-purchases.php?del=<?php echo $row['ID'];?>" class="btn btn-danger btn-sm" onclick="return confirm('Do you really want to delete this purchase order?');">Delete</a>
                  </td>
                </tr>
                <?php 
                $cnt=$cnt+1;
                }?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <?php include_once('includes/footer.php');?>
  </div>
</body>
</html>